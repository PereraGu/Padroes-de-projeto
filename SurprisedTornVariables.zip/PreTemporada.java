public class PreTemporada extends Treinamento {
    public void atividadeAerobica() {
      super.atividadeAerobica();
      super.hidratacao();
      System.out.println("corrida forte 10 minutos");
    }
}