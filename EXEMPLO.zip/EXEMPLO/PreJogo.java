public class PreJogo extends Treinamento {
    public void atividadeAerobica() {
      super.atividadeAerobica();
      super.hidratacao();
      System.out.println("corrida leve 10 minutos");
    }
}