public class TreinoDiario extends Treinamento {
    public void atividadeAerobica() {
      super.atividadeAerobica();
      super.hidratacao();
      System.out.println("corrida forte 30 minutos");
      super.hidratacao();
      System.out.println("corrida forte 30 minutos");
      super.hidratacao();
      System.out.println("corrida forte 20 minutos");
    }
}